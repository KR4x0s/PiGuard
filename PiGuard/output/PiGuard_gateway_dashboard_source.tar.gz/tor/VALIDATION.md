# Tor gateway validation — 2026-10-25

## Passed

- 24 local Python control/configuration tests (`PiGuard/tests/test_gateway.py`).
  They cover unsafe profiles, fixed live configuration paths, blocking on a failed
  Tor check, ordered transitions, state persistence failures, malformed check API
  responses, proxy-only curl behavior, and atomic replacement of only our nft table.
- 22 offline packet checks on the actual Pi kernel, inside newly created user and
  network namespaces. Three namespaces represented a gateway, downstream client,
  and upstream server; the tests used fake Tor/DNS endpoints. No physical interface
  was attached to the test network.
- Tor 0.4.9.14 `--verify-config` accepted the generated travel configuration,
  including the client-facing transparent listener.
- DNSCrypt-proxy 2.1.8 `-check` accepted the DNS relay configuration.
- Python compilation, shell syntax, and nftables 1.1.3 syntax validation passed.

The Tor/DNSCrypt Debian packages were downloaded and extracted into `/tmp` for
configuration checking. They were **not installed or launched**. The live
Pi-hole, ML observer, and existing dashboard remained active; the default route
remained through `wlan0` and 192.168.31.1.

## Kernel packet checks

1. IPv6 baseline works before the guard is installed.
2. Normal IPv4 uses the upstream server.
3. Normal UDP uses the upstream server.
4. External DNS requests are redirected to the simulated Pi-hole.
5. IPv6 bypass is blocked.
6. A persistent direct TCP connection works before Tor is selected.
7. That existing connection cannot continue directly after Tor is selected.
8. New client TCP reaches the simulated Tor transparent listener.
9. Unsupported UDP is blocked in Tor mode.
10. Tor mode retains the Pi-hole DNS path.
11. IPv6 remains blocked in Tor mode.
12. Private/reserved destination requests are rejected in Tor mode.
13. The upstream network cannot access the transparent proxy.
14. Stopping the simulated Tor process does not enable direct fallback.
15. Pi-hole-originated UDP DNS is redirected to the local relay.
16. Pi-hole-originated TCP DNS is redirected to the local relay.
17. Other Pi-hole upstream traffic is blocked in Tor mode.
18. The DNS relay user can reach the local Tor SOCKS endpoint.
19. The DNS relay user cannot fall back to a direct Internet connection.
20. Blocked mode stops client Internet.
21. Blocked mode stops client DNS.
22. Explicitly selecting normal mode restores ordinary IPv4 connectivity.

For UID-specific packet tests, the relevant generated UID match was mapped to
UID 0 **only inside the isolated user namespace**, where UID 0 maps to the ordinary
SSH user. Production rules require separate non-root `pihole` and `piguard-tor-dns`
accounts. The test harness refuses to run if its starting namespace contains
any interface besides loopback.

## Not yet verified

- Privileged dependency installation and systemd installation/startup on the live Pi.
- Actual Tor circuit bootstrap, exit confirmation, and real DNSCrypt-over-Tor traffic.
- Pi-hole/ML behavior after integration with the real relay.
- Real downstream client routing, DHCP, Wi-Fi AP mode, public-Wi-Fi captive portals,
  and both physical home/travel arrangements.
- Boot ordering, blocked recovery after reboot, power loss, and coexistence with
  other network/firewall managers.
- Pi 3B+ combined resource use and acceptable throughput/latency.

These checks are required before claiming live anonymity or gateway readiness.
The isolated tests validate the packet policy, not a production deployment.

## Reproduce

From the workspace root, using its existing Python test environment:

```bash
PiGuard_ML/.venv/bin/python -m pytest PiGuard/tests/test_gateway.py -q
bash -n PiGuard/scripts/install_gateway.sh PiGuard/scripts/install_gateway_deps.sh
```

On a Linux host with `ip`, `nft`, `nsenter`, `curl`, Python 3, and unprivileged
user/network namespaces enabled, from the `PiGuard` source directory:

```bash
unshare --user --map-root-user --net python3 tests/namespace_gateway.py
```

Do not remove the `unshare` wrapper or run this test directly in the host network.
