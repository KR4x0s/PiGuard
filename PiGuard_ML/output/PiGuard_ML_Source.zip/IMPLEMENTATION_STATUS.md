# PiGuard implementation status — 2026-10-25

## Implemented and verified

- Shared feature-v3 preprocessing with offline PSL and strict input modes.
- Leakage-resistant dataset cleaning, three trained candidates, immutable split manifest, locked selection policy, and one-time held-out evaluation.
- Read-only Pi-hole adapter, atomic checkpoints, reset/gap detection, concurrent-observer protection, bounded cache, review retention, and health states.
- Loopback-only dashboard with review history, CSRF protection, escaped content, filters, pagination, and CSV export.
- systemd units, scoped read-only database ACL helper, versioned installer, rollback/stop scripts, Colab notebook, and seven-day report command.
- All 67 tests passed on the Mac after the evaluation code changed. The earlier 67-test suite also passed on the physical Pi. Browser QA used synthetic fixture traffic.

## Training and model selection

Raw rows: 91,599. Removed 377 duplicate effective labels and two rows in one conflicting group. Clean rows: 91,220 (42,075 benign; 49,145 DGA). Split: 63,854 train / 13,683 validation / 13,683 test. No DGA-family labels were available.

| Candidate | Validation recall | Validation precision | Validation FPR | Threshold |
|---|---:|---:|---:|---:|
| logistic_regression | 50.02% | 98.32% | 1.00% | 0.889362 |
| compact_random_forest | 56.80% | 98.52% | 1.00% | 0.891434 |
| random_forest | 56.87% | 98.52% | 1.00% | 0.927143 |

The selection policy was locked in `runs/2026-10-25-baseline/evaluation_policy.json` before opening the test set. It requires ARM64 reference parity, scorer peak RSS ≤256 MiB, and warm uncached batch500 p95 ≤2,000 ms. The collector polls every 15 seconds and gives each 500-record drain two seconds. Pi results from 20 batches:

| Candidate | Scorer peak RSS | Batch500 p95 | Selection |
|---|---:|---:|---|
| Logistic regression | 155.66 MiB | 1,478.54 ms | Eligible |
| Compact random forest | 178.40 MiB | 1,205.57 ms | Selected by higher validation recall |
| Original random forest | 374.75 MiB in prior benchmark | Not re-benchmarked at batch500 | Excluded by memory |

The Pi's reference feature, prediction, and decision vectors passed. See `runs/2026-10-25-baseline/benchmark-pi-batch500.json` and the release's copied policy/benchmark.

## One-time held-out evaluation

The held-out test was consumed once. `runs/2026-10-25-baseline/FINAL_EVALUATED.json` records that event; **do not rerun or retune against it**. The immutable output is `releases/final-001`, with trusted manifest SHA-256 `fc4f50f35b2f70d976cb10036e0eb6dff2253f5ef54b5c21d685683b33cf8b21`.

| Test measure | Result |
|---|---:|
| Rows | 13,683 |
| True negatives / false positives | 6,263 / 48 |
| False negatives / true positives | 3,184 / 4,188 |
| Precision | 98.87% |
| Recall | 56.81% |
| False-positive rate | 0.76% |
| F1 | 72.16% |
| ROC-AUC / average precision | 0.920 / 0.942 |

The public test set contains about 54% DGA rows, so its precision does not predict precision or daily alert burden on a home network. The 3,184 false negatives are a material limitation. The same-source split does not test unseen DGA families. The release includes slices, Wilson intervals, a plot, and error examples.

## Live Pi deployment

On 2026-10-25, the operator activated the compact-forest **candidate** in alert-only mode. The installer checked the trusted manifest, Python/dependencies, reference vectors, Pi-hole `queries` schema, and read-only source access. It enabled the observer, dashboard, ACL path unit, and ACL timer. The health endpoint returned HTTP 200 with `model_ready=true`, `model_stage=candidate`, `error=null`, and `backlog=0`. The checkpoint advanced through live persisted DNS records. The dashboard returned HTTP 200 through a Mac SSH tunnel at http://127.0.0.1:8080. Steady RSS sampled at about 179 MiB observer plus 93 MiB dashboard; this was not peak memory.

The evaluated final bundle passed manifest digest and inference/reference checks on the Pi. The operator ran `bash ~/PiGuard_ML_20261025/scripts/activate_final.sh` with sudo authentication. `/opt/piguard/current` now points to `/opt/piguard/releases/20261025T134356Z-fc4f50f35b2f`, whose manifest matches the trusted SHA-256. The observer, dashboard, ACL path unit, and ACL timer are active and enabled. Health returned HTTP 200 with `model_stage=evaluated`, `model_ready=true`, `ready=true`, `error=null`, and `backlog=0`; the checkpoint advanced from 4671 before the upgrade to 4678 afterward. The dashboard returned HTTP 200 on the Pi and through the private Mac localhost SSH tunnel. The installer retains the separate alert state and does not change Mac DNS or Pi-hole blocking policy.

Mac Wi-Fi DNS remains automatic. When it was briefly directed to Pi-hole, ChatGPT repeatedly reconnected; the user confirmed connectivity recovered after restoring automatic DNS. Explicit DNS probes did not prove ordinary application reliability. That client issue predates ML service activation and remains separate.

## Remaining deployment evidence

1. Resolve one-client DNS reliability before routing ordinary application traffic through the Pi.
2. Measure alert appearance, combined peak memory, DNS overhead, timeouts, and restart/reboot recovery on the live installation.
3. Keep model and threshold frozen for seven complete UTC days and review the resulting alert burden. Do not infer home-network detection precision from the public dataset.
