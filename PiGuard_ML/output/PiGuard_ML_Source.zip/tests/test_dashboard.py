import time
import pytest
from piguard.dashboard import create_app, csv_safe
from piguard.observer import Observer
from piguard.storage import connect,set_meta
from conftest import put_query

@pytest.fixture
def client(source,tmp_path,scorer):
    state=tmp_path/'state.db'
    put_query(source,1,'example.com')
    Observer(source,state,scorer,replay=True).tick()
    app=create_app(state,'test-secret')
    app.config['TESTING']=True
    return app.test_client()


def test_home_filter_detail_export(client):
    assert b'example.com' in client.get('/').data
    assert b'No matching alerts' in client.get('/?domain=missing').data
    assert client.get('/?status=wrong').status_code==400
    assert client.get('/?page=oops').status_code==400
    assert client.get('/alerts/999').status_code==404
    assert b'Decision evidence' in client.get('/alerts/1').data
    assert b'example.com' in client.get('/export.csv').data
    assert client.get('/healthz').status_code==200


def test_review_csrf_escape_and_persistence(client):
    client.get('/')
    assert client.post('/alerts/1',data={'review_status':'benign'}).status_code==403
    with client.session_transaction() as session:
        csrf=session['csrf']
    assert client.post('/alerts/1',data={'csrf':csrf,'review_status':'wrong'}).status_code==400
    response=client.post('/alerts/1',data={'csrf':csrf,'review_status':'benign','note':'<script>alert(1)</script>'})
    assert response.status_code==303
    detail=client.get('/alerts/1').data
    assert b'&lt;script&gt;' in detail and b'<script>' not in detail
    assert b'example.com' in client.get('/?status=benign').data
    assert b'No matching alerts' in client.get('/?status=new').data


def test_stale_health_and_host_guard(tmp_path):
    app=create_app(tmp_path/'state.db','secret')
    client=app.test_client()
    assert client.get('/healthz').status_code==503
    assert b'Observation needs attention' in client.get('/').data
    assert client.get('/',headers={'Host':'attacker.example'}).status_code==400
    assert 'frame-ancestors' in client.get('/').headers['Content-Security-Policy']

@pytest.mark.parametrize('value',['=SUM(1,2)','+cmd','-cmd','@cmd','  =SUM(1,2)','\t=cmd'])
def test_csv_escape(value):
    assert csv_safe(value).startswith("'")
